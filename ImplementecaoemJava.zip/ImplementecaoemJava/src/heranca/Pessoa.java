
package heranca;

    public class Pessoa{
    private String nome;
    private int idade;
    
    public Pessoa(String nome, int idade){ //construtor 
        this.nome = nome;
        this.idade = idade;
    }
    public String getNome(){ // get nome
        return nome;
    }
    public void setNome(){ //set nome
        this.nome=nome;
    }
    public int getIdade(){
        return idade;
    }
    public void setIdade(){
        this.idade = idade;
    }
    public void mostrarDados(){
        System.out.println("Nome: "+ nome);
        System.out.println("Idade: "+ idade);
    }
 }
  
 
