
package heranca;

public class ChefDepartamento extends Funcionario {
    private String departamento;

    public ChefDepartamento(String nome,int idade,double salario, String departamento){
        super(nome, idade, salario);
        this.departamento = departamento;
    }
    
    @Override
    public void mostrarDados(){
        super.mostrarDados();
        System.out.println("Departamento "+departamento);
    }
}
