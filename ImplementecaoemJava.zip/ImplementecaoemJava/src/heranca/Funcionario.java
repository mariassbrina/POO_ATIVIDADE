package heranca;

public class Funcionario extends Pessoa{
        private final double salario;
    public Funcionario(String nome, int idade, double salario){//construtor
          super(nome,idade);//referencia a classe pai, chamado os atributos
          this.salario = salario;
    }
         
    @Override
    public void mostrarDados(){
        super.mostrarDados();
        System.out.println("Salário: "+ salario);
    }
}
