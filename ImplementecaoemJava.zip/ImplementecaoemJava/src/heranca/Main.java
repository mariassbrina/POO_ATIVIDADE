/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heranca;

/**
 *
 * @author maria.sabrina
 */
public class Main {
    
  public static void main(String[] args){
   ChefDepartamento chefe = new ChefDepartamento("Samuel", 40, 5000.0, "TI");
        System.out.println("Dados do Chefe de Departamento:");
        chefe.mostrarDados();
  }
    
}
